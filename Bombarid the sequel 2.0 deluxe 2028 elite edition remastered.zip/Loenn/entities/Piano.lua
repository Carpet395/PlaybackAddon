local drawableSprite = require("structs.drawable_sprite")
local Piano = {}
local noteNames = {
    {"E6", 24},
    {"D#/Eb6", 23},
    {"D6", 22},
    {"C#/Db6", 21},
    {"C6", 20},
    {"B5", 19},
    {"A#/Bb5", 18},
    {"A5", 17},
    {"G#/Ab5", 16},
    {"G5", 15},
    {"F#/Gb5", 14},
    {"F5", 13},
    {"E5", 12},
    {"D#/Eb5", 11},
    {"D5", 10},
    {"C#/Db5", 9},
    {"C5", 8},
    {"B4", 7},
    {"A#/Bb4", 6},
    {"A4", 5},
    {"G#/Ab4", 4},
    {"G4", 3},
    {"F#/Gb4", 2},
    {"F4", 1},
    {"E4",  0},
}
local sounds ={
    "event:/vert_audiohelper/bell",
    "event:/vert_audiohelper/chime"
}

Piano.name = "playback/piano"
Piano.depth = 100
Piano.fieldInformation = {
    Left = {
        fieldType = "integer",
        options = noteNames,
        editable = false,
    },
    Right = {
        fieldType = "integer",
        options = noteNames,
        editable = false,
    },
    Up = {
        fieldType = "integer",
        options = noteNames,
        editable = false,
    },
    Down = {
        fieldType = "integer",
        options = noteNames,
        editable = false,
    },
    UpLeft = {
        fieldType = "integer",
        options = noteNames,
        editable = false,
    },
    DownLeft = {
        fieldType = "integer",
        options = noteNames,
        editable = false,
    },
    DownRight = {
        fieldType = "integer",
        options = noteNames,
        editable = false,
    },
    Middle = {
        fieldType = "integer",
        options = noteNames,
        editable = false,
    },
    LeftShift = {
        fieldType = "integer",
        options = noteNames,
        editable = false,
    },
    RightShift = {
        fieldType = "integer",
        options = noteNames,
        editable = false,
    },
    UpShift = {
        fieldType = "integer",
        options = noteNames,
        editable = false,
    },
    DownShift = {
        fieldType = "integer",
        options = noteNames,
        editable = false,
    },
    UpLeftShift = {
        fieldType = "integer",
        options = noteNames,
        editable = false,
    },
    DownLeftShift = {
        fieldType = "integer",
        options = noteNames,
        editable = false,
    },
    DownRightShift = {
        fieldType = "integer",
        options = noteNames,
        editable = false,
    },
    MiddleShift = {
        fieldType = "integer",
        options = noteNames,
        editable = false,
    }
}
function Piano.ignoredFields(entity)
    local ignored = {   
        "Mode",
    }

    local function doNotIgnore(value)
        for i = #ignored, 1, -1 do
            if ignored[i] == value then
                table.remove(ignored, i)
                return
            end
        end
    end

    return ignored
end

Piano.placements = {
    {
        name = "Piano (Fourway)",
        data = {
            Mode = "FourWay",
            Middle = 0,
            Up = 0,
            Down = 0,
            Left = 0,
            Right = 0,
        }
    },
    {
        name = "Piano (Eightway)",
        data = {
            Mode = "EightWay",
            Middle = 0,
            Up = 0,
            Down = 0,
            Left = 0,
            UpLeft = 0,
            DownLeft = 0,
            Right = 0,
            DownRight = 0
        }
    },
        {
        name = "Piano (Fourway Shift)",
        data = {
            Mode = "FourWayShift",
            Middle = 0,
            Up = 0,
            Down = 0,
            Left = 0,
            Right = 0,
            MiddleShift = 0,
            UpShift = 0,
            DownShift = 0,
            LeftShift = 0,
            RightShift = 0,
        }
    },
    {
        name = "Piano (Eightway Shift)",
        data = {
            Mode = "EightWayShift",
            MiddleShift = 0,
            UpShift = 0,
            DownShift = 0,
            LeftShift = 0,
            UpLeftShift = 0,
            DownLeftShift = 0,
            RightShift = 0,
            DownRightShift = 0,

            Middle = 0,
            Up = 0,
            Down = 0,
            Left = 0,
            UpLeft = 0,
            DownLeft = 0,
            Right = 0,
            DownRight = 0
        }
    }
}

function Piano.sprite(room, entity)
    local sprite = drawableSprite.fromTexture("objects/bellpiano/piano_wip", entity)
    sprite:setJustification(-0.00, -0.00)
    sprite:setColor(entity.colour)
    return sprite
end

return Piano